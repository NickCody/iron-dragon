#ifndef __LICENSE_H__
#define __LICENSE_H__

int  Check_Admin_License  ( uint_08* License_Data );
void Create_Admin_License ( uint_08* Lic );
const char* Auto_Generate_Password ( );

#endif // __LICENSE_H__